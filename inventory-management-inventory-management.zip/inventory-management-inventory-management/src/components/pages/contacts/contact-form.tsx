
"use client";

import { useEffect, useTransition } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useLanguage } from '@/contexts/language-context';
import type { Buyer, Vendor } from '@/lib/types';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { saveContactAction } from '@/app/(dashboard)/contacts/actions';

const formSchema = z.object({
    id: z.number().optional(),
    name: z.string().min(2, { message: "Name must be at least 2 characters." }),
    phone: z.string().optional(),
    address: z.string().optional(),
});

export type ContactFormData = z.infer<typeof formSchema>;

type ContactFormProps = {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    contact?: Buyer | Vendor | null;
    contactType: 'buyers' | 'vendors';
};

export function ContactForm({ isOpen, onClose, onSuccess, contact, contactType }: ContactFormProps) {
    const { t } = useLanguage();
    const { toast } = useToast();
    const [isPending, startTransition] = useTransition();

    const form = useForm<ContactFormData>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            id: undefined,
            name: '',
            phone: '',
            address: '',
        },
    });

    useEffect(() => {
        if (isOpen) {
            if (contact) {
                form.reset({
                    id: contact.id,
                    name: contact.name,
                    phone: contact.phone || '',
                    address: (contact as Buyer).address || '',
                });
            } else {
                form.reset({ id: undefined, name: '', phone: '', address: '' });
            }
        }
    }, [contact, isOpen, form]);

    const onSubmit = (values: ContactFormData) => {
        startTransition(async () => {
            const result = await saveContactAction(values, contactType);
            if (result.success) {
                toast({ title: "Success", description: result.message });
                onSuccess();
            } else {
                toast({ title: "Error", description: result.message, variant: "destructive" });
            }
        });
    };
    
    const titleKey = contact ? 'edit' : 'addContact';
    const typeKey = contactType === 'buyers' ? t.buyers : t.vendors;
    const title = `${t[titleKey]} ${typeKey}`;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{title}</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t.name}</FormLabel>
                                    <FormControl>
                                        <Input placeholder="Enter name" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t.phone}</FormLabel>
                                    <FormControl>
                                        <Input placeholder="Enter phone number" {...field} value={field.value || ''} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        {contactType === 'buyers' && (
                             <FormField
                                control={form.control}
                                name="address"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t.address}</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Enter address" {...field} value={field.value || ''}/>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        )}
                        <DialogFooter>
                            <Button type="button" variant="secondary" onClick={onClose}>{t.cancel}</Button>
                            <Button type="submit" disabled={isPending}>
                                {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t.save}
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
}
