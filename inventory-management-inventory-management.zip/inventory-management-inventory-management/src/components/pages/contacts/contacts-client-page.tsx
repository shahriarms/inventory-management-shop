
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLanguage } from "@/contexts/language-context";
import { PlusCircle, Trash2, Edit, Loader2 } from "lucide-react";
import { ContactForm, type ContactFormData } from "@/components/pages/contacts/contact-form";
import type { Buyer, Vendor } from "@/lib/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast";
import { deleteContactAction } from "@/app/(dashboard)/contacts/actions";


export function ContactsClientPage({
    initialBuyers,
    initialVendors,
}: {
    initialBuyers: Buyer[],
    initialVendors: Vendor[]
}) {
    const { toast } = useToast();
    const { t } = useLanguage();
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingContact, setEditingContact] = useState<Buyer | Vendor | null>(null);
    const [contactToDelete, setContactToDelete] = useState<(Buyer | Vendor) & { type: 'buyers' | 'vendors' } | null>(null);
    const [activeTab, setActiveTab] = useState('buyers');
    const [isPending, setIsPending] = useState(false);

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
    }

    const handleAddClick = () => {
        setEditingContact(null);
        setIsFormOpen(true);
    };

    const handleEditClick = (contact: Buyer | Vendor) => {
        setEditingContact(contact);
        setIsFormOpen(true);
    };
    
    const handleDeleteClick = (contact: Buyer | Vendor, type: 'buyers' | 'vendors') => {
        setContactToDelete({ ...contact, type });
    };

    const confirmDelete = async () => {
        if (!contactToDelete) return;
        setIsPending(true);
        
        const result = await deleteContactAction(contactToDelete.id, contactToDelete.type);
        
        if (result.success) {
            toast({ title: "Success", description: result.message });
        } else {
            toast({ title: "Error", description: result.message, variant: "destructive" });
        }
        
        setContactToDelete(null);
        setIsPending(false);
    };

    const handleFormSuccess = () => {
        setIsFormOpen(false);
        setEditingContact(null);
        // The server action will revalidate the path, so we don't need to manually refresh state.
    };

    return (
        <>
            <ContactForm
                isOpen={isFormOpen}
                onClose={() => setIsFormOpen(false)}
                onSuccess={handleFormSuccess}
                contact={editingContact}
                contactType={activeTab as 'buyers' | 'vendors'}
            />

            <AlertDialog open={!!contactToDelete} onOpenChange={() => setContactToDelete(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete this contact.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={confirmDelete} disabled={isPending} variant="destructive">
                        {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete"}
                    </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>


            <Tabs defaultValue="buyers" className="w-full" onValueChange={setActiveTab}>
                <div className="flex items-center justify-between mb-6">
                     <TabsList>
                        <TabsTrigger value="buyers">{t.buyers}</TabsTrigger>
                        <TabsTrigger value="vendors">{t.vendors}</TabsTrigger>
                    </TabsList>
                    <Button onClick={handleAddClick}>
                        <PlusCircle className="h-4 w-4 mr-2" />{t.addContact}
                    </Button>
                </div>
                <TabsContent value="buyers">
                    <Card>
                        <CardHeader>
                            <CardTitle>{t.buyers}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>{t.name}</TableHead>
                                        <TableHead>{t.phone}</TableHead>
                                        <TableHead>{t.address}</TableHead>
                                        <TableHead className="text-right">{t.outstandingDues}</TableHead>
                                        <TableHead className="text-center">{t.actions}</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {initialBuyers.map((buyer) => (
                                        <TableRow key={buyer.id}>
                                            <TableCell className="font-medium">{buyer.name}</TableCell>
                                            <TableCell>{buyer.phone || 'N/A'}</TableCell>
                                            <TableCell>{buyer.address || 'N/A'}</TableCell>
                                            <TableCell className="text-right text-red-500 font-semibold">{formatCurrency(buyer.due || 0)}</TableCell>
                                            <TableCell className="text-center">
                                                <div className="flex items-center justify-center gap-2">
                                                    <Button variant="outline" size="icon" onClick={() => handleEditClick(buyer)}><Edit className="h-4 w-4" /></Button>
                                                    <Button variant="destructive" size="icon" onClick={() => handleDeleteClick(buyer, 'buyers')} disabled={isPending}>
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="vendors">
                    <Card>
                        <CardHeader>
                            <CardTitle>{t.vendors}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>{t.name}</TableHead>
                                        <TableHead>{t.phone}</TableHead>
                                        <TableHead className="text-center">{t.actions}</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {initialVendors.map((vendor) => (
                                        <TableRow key={vendor.id}>
                                            <TableCell className="font-medium">{vendor.name}</TableCell>
                                            <TableCell>{vendor.phone || 'N/A'}</TableCell>
                                            <TableCell className="text-center">
                                                <div className="flex items-center justify-center gap-2">
                                                    <Button variant="outline" size="icon" onClick={() => handleEditClick(vendor)}><Edit className="h-4 w-4" /></Button>
                                                    <Button variant="destructive" size="icon" onClick={() => handleDeleteClick(vendor, 'vendors')} disabled={isPending}>
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </>
    );
}
