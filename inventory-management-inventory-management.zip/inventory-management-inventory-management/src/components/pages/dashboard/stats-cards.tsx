
"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/contexts/language-context"
import { DollarSign, ShoppingBasket, ShoppingCart } from "lucide-react"

type Period = 'weekly' | 'monthly'; // Simplified for this design

type SalesData = {
    [key in Period]: {
        revenue: number;
        profit: number; // Will be used as "Sale Count"
        expenses: number;
        itemsSold: number; // Will be used as "Basket Size"
    }
}

type StatsCardsProps = {
    salesData: SalesData & { daily: any };
}

export function StatsCards({ salesData }: StatsCardsProps) {
  const { t } = useLanguage();

  const monthlyData = salesData.monthly;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
  }

  const getPercentageColor = (text: string) => {
    if (text.startsWith('+')) return 'text-green-500';
    if (text.startsWith('-')) return 'text-red-500';
    return 'text-muted-foreground';
  };
  
  const revenueChange = "+22% This Month";
  const salesChange = "+15% This Month";
  const itemsSoldChange = "+5% This Month";


  return (
    <div className="flex flex-col gap-6">
        <h3 className="text-lg font-semibold text-foreground/80">Key Metrics</h3>
        <Card>
            <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2 text-foreground/70">
                    <DollarSign className="h-4 w-4" />
                    <span>Total Revenue</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-3xl font-bold text-foreground">{formatCurrency(monthlyData.revenue)}</p>
                <p className={`text-xs ${getPercentageColor(revenueChange)}`}>{revenueChange}</p>
            </CardContent>
        </Card>
        <Card>
             <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2 text-foreground/70">
                    <ShoppingCart className="h-4 w-4" />
                    <span>Total Sales</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-3xl font-bold">{monthlyData.profit}</p>
                <p className={`text-xs ${getPercentageColor(salesChange)}`}>{salesChange}</p>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2 text-foreground/70">
                    <ShoppingBasket className="h-4 w-4" />
                    <span>Items Sold</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-3xl font-bold">{monthlyData.itemsSold.toFixed(0)}</p>
                <p className={`text-xs ${getPercentageColor(itemsSoldChange)}`}>{itemsSoldChange}</p>
            </CardContent>
        </Card>
    </div>
  )
}
