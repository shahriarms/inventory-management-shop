
"use client"

import * as React from "react"
import { Check, ChevronsUpDown, PlusCircle, Loader2 } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

type ComboboxOption = {
    label: string;
    value: string;
    address?: string; // Make address optional
}

type ComboboxProps = {
    options: ComboboxOption[];
    onSelect: (value: string) => void;
    placeholder: string;
    searchPlaceholder: string;
    selectedValue?: string;
    onAdd?: (newLabel: string) => void;
    isAdding?: boolean;
}

export function Combobox({ options, onSelect, placeholder, searchPlaceholder, selectedValue, onAdd, isAdding = false }: ComboboxProps) {
  const [open, setOpen] = React.useState(false)
  const [search, setSearch] = React.useState("")

  const filteredOptions = options.filter(option => option.label.toLowerCase().includes(search.toLowerCase()))
  
  const showAddNew = onAdd && search.length > 0 && !filteredOptions.some(o => o.label.toLowerCase() === search.toLowerCase());

  const handleSelect = (optionValue: string) => {
    onSelect(optionValue)
    setOpen(false)
    setSearch("")
  }

  const handleAddNew = () => {
    if (onAdd) {
      onAdd(search)
      setOpen(false)
      setSearch("")
    }
  }

  const selectedLabel = options.find((option) => option.value === selectedValue)?.label;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
        >
          {selectedLabel || placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0" style={{ minWidth: 'var(--radix-popover-trigger-width)' }}>
        <Command>
          <CommandInput 
            placeholder={searchPlaceholder}
            value={search}
            onValueChange={setSearch}
          />
          <CommandList>
            {filteredOptions.length === 0 && !showAddNew && !isAdding && (
                <CommandEmpty>No option found.</CommandEmpty>
            )}
             {isAdding && (
                <div className="flex items-center justify-center p-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Adding...</span>
                </div>
            )}
            <CommandGroup>
              {filteredOptions.map((option) => (
                <CommandItem
                  key={option.value}
                  value={option.label}
                  onSelect={() => handleSelect(option.value)}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      selectedValue === option.value ? "opacity-100" : "opacity-0"
                    )}
                  />
                  <div>
                    <p className="font-medium">{option.label}</p>
                    {option.address && <p className="text-xs text-muted-foreground">{option.address}</p>}
                  </div>
                </CommandItem>
              ))}
              {showAddNew && !isAdding && (
                <CommandItem onSelect={handleAddNew} className="text-primary hover:!text-primary cursor-pointer">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add new buyer "{search}"
                </CommandItem>
              )}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
