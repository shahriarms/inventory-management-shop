
import type { Translations } from "@/lib/i18n";
import { LayoutDashboard, FileText, Warehouse, Users, PlusCircle, Settings } from "lucide-react";

export const getNavItems = (t: Translations['en'] | Translations['bn']) => [
    {
        href: "/dashboard",
        label: t.dashboard,
        icon: LayoutDashboard,
    },
    {
        href: "/inventory",
        label: t.inventory,
        icon: Warehouse,
    },
    {
        href: "/invoices/new",
        label: t.createInvoice,
        icon: PlusCircle,
    },
    {
        href: "/invoices",
        label: t.invoices,
        icon: FileText,
    },
    {
        href: "/contacts",
        label: t.contacts,
        icon: Users,
    },
    {
        href: "/settings",
        label: t.settings,
        icon: Settings,
    }
];
