
"use client"

import { useLanguage } from "@/contexts/language-context"

export function AppProvider({ children }: { children: React.ReactNode }) {
  const { isMounted } = useLanguage();
  
  if (!isMounted) {
    return null; // or a loading spinner
  }

  return <>{children}</>;
}
