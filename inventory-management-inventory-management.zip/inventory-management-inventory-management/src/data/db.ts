
import { sql } from "@vercel/postgres";
import type { Buyer, Vendor } from "@/lib/types";
import { unstable_noStore as noStore } from 'next/cache';

export async function getBuyers(): Promise<Buyer[]> {
  noStore();
  try {
    const { rows } = await sql`SELECT id, name, phone, address, due FROM buyers ORDER BY name ASC`;
    return rows as Buyer[];
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch buyers.');
  }
}

export async function getVendors(): Promise<Vendor[]> {
  noStore();
  try {
    const { rows } = await sql`SELECT id, name, phone FROM vendors ORDER BY name ASC`;
    return rows as Vendor[];
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch vendors.');
  }
}

export async function addBuyer(name: string, phone: string | null, address: string | null) {
  try {
    await sql`
      INSERT INTO buyers (name, phone, address, due)
      VALUES (${name}, ${phone}, ${address}, 0)
    `;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to add buyer.');
  }
}

export async function updateBuyer(id: number, name: string, phone: string | null, address: string | null) {
  try {
    await sql`
      UPDATE buyers
      SET name = ${name}, phone = ${phone}, address = ${address}
      WHERE id = ${id}
    `;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to update buyer.');
  }
}

export async function deleteBuyer(id: number) {
  try {
    await sql`DELETE FROM buyers WHERE id = ${id}`;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to delete buyer.');
  }
}


export async function addVendor(name: string, phone: string | null) {
  try {
    await sql`
      INSERT INTO vendors (name, phone)
      VALUES (${name}, ${phone})
    `;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to add vendor.');
  }
}

export async function updateVendor(id: number, name: string, phone: string | null) {
  try {
    await sql`
      UPDATE vendors
      SET name = ${name}, phone = ${phone}
      WHERE id = ${id}
    `;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to update vendor.');
  }
}

export async function deleteVendor(id: number) {
  try {
    await sql`DELETE FROM vendors WHERE id = ${id}`;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to delete vendor.');
  }
}
