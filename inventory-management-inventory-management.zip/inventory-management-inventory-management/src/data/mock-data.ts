
import type { Buyer, Vendor, Product, Invoice } from "@/lib/types";

export const products: Product[] = [
    { id: 1, name: "1 inch Pipe", sku: "PIPE-1", quantity: 100, price: 120 },
    { id: 2, name: "2 inch Pipe", sku: "PIPE-2", quantity: 50, price: 180 },
    { id: 3, name: "Welding Rod", sku: "WELD-ROD", quantity: 500, price: 15 },
    { id: 4, name: "Grinding Disc", sku: "GRIND-DISC", quantity: 200, price: 250 },
    { id: 5, name: "Drill Bit Set", sku: "DRILL-SET", quantity: 80, price: 800 },
];

export const buyers: Buyer[] = [
    { id: 1, name: "Abul Kalam", phone: "01711111111", address: "Dhaka, Bangladesh", due: 1500 },
    { id: 2, name: "Babul Hossain", phone: "01822222222", address: "Chittagong, Bangladesh", due: 0 },
    { id: 3, name: "Karim Sheikh", phone: "01933333333", address: "Sylhet, Bangladesh", due: 5200 },
];

export const vendors: Vendor[] = [
    { id: 1, name: "BSRM Steels", phone: "01511111111" },
    { id: 2, name: "Anwar Cement", phone: "01622222222" },
];

export const invoices: Invoice[] = [
    { id: 1001, buyer: "Abul Kalam", date: "2023-10-26", total: 5000, due: 1500 },
    { id: 1002, buyer: "Karim Sheikh", date: "2023-10-25", total: 8000, due: 5200 },
    { id: 1003, buyer: "Babul Hossain", date: "2023-10-24", total: 2500, due: 0 },
];

export const salesData = {
    daily: { revenue: 4500, profit: 900, expenses: 150, itemsSold: 12 },
    weekly: { revenue: 31500, profit: 6300, expenses: 950, itemsSold: 88 },
    monthly: { revenue: 125000, profit: 25000, expenses: 4300, itemsSold: 350 },
};

const chartColors = [
    '#22c55e', // Green
    '#3b82f6', // Blue
    '#6366f1', // Indigo
    '#8b5cf6', // Violet
    '#a855f7', // Purple
    '#d946ef', // Fuchsia
    '#ec4899', // Pink
];

export const salesChartData = [
    { date: 'Mon', sales: 4000, fill: chartColors[0] },
    { date: 'Tue', sales: 3000, fill: chartColors[1] },
    { date: 'Wed', sales: 2000, fill: chartColors[2] },
    { date: 'Thu', sales: 2780, fill: chartColors[3] },
    { date: 'Fri', sales: 1890, fill: chartColors[4] },
    { date: 'Sat', sales: 2390, fill: chartColors[5] },
    { date: 'Sun', sales: 3490, fill: chartColors[6] },
];
