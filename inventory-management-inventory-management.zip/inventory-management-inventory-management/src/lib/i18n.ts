
export type Language = 'en' | 'bn';

const en = {
  // Navigation
  dashboard: 'Dashboard',
  inventory: 'Inventory',
  invoices: 'Invoices',
  contacts: 'Contacts',
  settings: 'Settings',
  
  // Dashboard
  dailySales: 'Daily Sales',
  weeklySales: 'Weekly Sales',
  monthlySales: 'Monthly Sales',
  totalRevenue: 'Total Revenue',
  totalProfit: 'Total Profit',
  expenses: 'Expenses',
  itemsSold: 'Items Sold',
  salesOverview: 'Sales Overview',
  
  // Inventory
  productName: 'Product Name',
  sku: 'SKU/Barcode',
  quantity: 'Quantity',
  price: 'Price',
  actions: 'Actions',
  addProduct: 'Add Product',
  editProduct: 'Edit Product',
  deleteProduct: 'Delete Product',
  import: 'Import',
  export: 'Export',
  searchProducts: 'Search products...',

  // Invoices
  createInvoice: 'Create Invoice',
  invoice: 'Invoice',
  buyerInfo: 'Buyer Info',
  invoiceDate: 'Invoice Date',
  item: 'Item',
  rate: 'Rate',
  discount: 'Discount',
  total: 'Total',
  subtotal: 'Subtotal',
  due: 'Due',
  paidAmount: 'Paid Amount',
  saveInvoice: 'Save Invoice',
  invoiceInfo: 'Invoice Information',
  invoiceNo: 'Invoice No',
  date: 'Date',
  selectBuyer: 'Select buyer',
  enterBuyerAddress: "Enter buyer's address",
  addProducts: "Add Products",
  addLineItem: "Add Line Item",
  selectItem: "Select an item",
  cashMemo: "Cash Memo",
  shopAddress: "Address: Pabna, Ishwardi, arambaria, Majhdiar. Arambaria Bazar, beside Grameen Bank, Sirajganj.",
  shopContact: "Owner: 01775-136823, Manager: 01874-686148, E-mail: engmahmud.mmm@gmail.com",
  invoiceItems: "Invoice Items",
  serialNo: "Sl. No.",
  itemDescription: "Item Description",
  amount: "Amount",
  noItemsAdded: "No items added yet.",
  amountInWords: "Amount in words",
  amountInWordsPlaceholder: "Zero Taka Only",
  saveAndPrintInvoice: "Save & Print Invoice",
  address: "Address",
  name: 'Name',
  phone: 'Phone',


  // Contacts
  buyers: 'Buyers',
  vendors: 'Vendors',
  outstandingDues: 'Outstanding Dues',
  addContact: 'Add Contact',

  // General
  edit: 'Edit',
  delete: 'Delete',
  save: 'Save',
  cancel: 'Cancel',
  language: 'Language',
  english: 'English',
  bengali: 'Bengali',
};

const bn = {
  // Navigation
  dashboard: 'ড্যাশবোর্ড',
  inventory: 'ইনভেন্টরি',
  invoices: 'ইনভয়েস',
  contacts: 'পরিচিতি',
  settings: 'সেটিংস',
  
  // Dashboard
  dailySales: 'দৈনিক বিক্রয়',
  weeklySales: 'সাপ্তাহিক বিক্রয়',
  monthlySales: 'মাসিক বিক্রয়',
  totalRevenue: 'মোট রাজস্ব',
  totalProfit: 'মোট লাভ',
  expenses: 'খরচ',
  itemsSold: 'বিক্রি হওয়া পণ্য',
  salesOverview: 'বিক্রয় ওভারভিউ',
  
  // Inventory
  productName: 'পণ্যের নাম',
  sku: 'এসকিউ/বারকোড',
  quantity: 'পরিমাণ',
  price: 'মূল্য',
  actions: 'ক্রিয়াকলাপ',
  addProduct: 'পণ্য যোগ করুন',
  editProduct: 'পণ্য সম্পাদনা করুন',
  deleteProduct: 'পণ্য মুছুন',
  import: 'ইম্পোর্ট',
  export: 'এক্সপোর্ট',
  searchProducts: 'পণ্য খুঁজুন...',

  // Invoices
  createInvoice: 'ইনভয়েস তৈরি করুন',
  invoice: 'ইনভয়েস',
  buyerInfo: 'ক্রেতার তথ্য',
  invoiceDate: 'ইনভয়েসের তারিখ',
  item: 'পণ্য',
  rate: 'দর',
  discount: 'ছাড়',
  total: 'মোট',
  subtotal: 'উপমোট', // Changed
  due: 'বাকী', // Changed
  paidAmount: 'জমা', // Changed
  saveInvoice: 'ইনভয়েস সংরক্ষণ করুন',
  invoiceInfo: "চালান তথ্য",
  invoiceNo: "ক্রঃ নং",
  date: "তারিখ",
  selectBuyer: "ক্রেতার নাম লিখুন",
  enterBuyerAddress: "ক্রেতার ঠিকানা লিখুন",
  addProducts: "পণ্য যোগ করুন",
  addLineItem: "লাইন যোগ করুন",
  selectItem: "পণ্য সিলেক্ট করুন",
  cashMemo: "ক্যাশ মেমো",
  shopAddress: "এখানে ওয়েল্ডিং, গ্রিল, শিট সহ সকল প্রকার ওয়ার্কশপ এর মালামাল এবং হার্ডওয়ার সামগ্রি, গ্রেন্ডিং মেশিন, ড্রিল মেশিন, হাই-স্পীড কাটার ও যন্ত্রপাতি বিক্রয় করা হয়।",
  shopContact: "মালিকঃ ০১৭৭৫-১৩৬৮২৩, ম্যানেজারঃ ০১৮৭৪-৬৮৬১৪৮ E-mail: engmahmud.mmm@gmail.com ধনারহাট সংলগ্ন, রূপপুর নতুনপাড়া রোড, শাহজাদপুর, সিরাজগঞ্জ।",
  invoiceItems: "ইনভয়েস আইটেম",
  serialNo: "ক্রঃ নং",
  itemDescription: "মালের বিবরণ",
  amount: "টাকা",
  noItemsAdded: "এখনও কোনো আইটেম যোগ করা হয়নি।",
  amountInWords: "টাকা কথায়ঃ",
  amountInWordsPlaceholder: "শূন্য টাকা মাত্র",
  saveAndPrintInvoice: "চালান সেভ করুন",
  address: "ঠিকানা",
  name: 'নাম',
  phone: 'ফোন',
  
  // Contacts
  buyers: 'ক্রেতা',
  vendors: 'বিক্রেতা',
  outstandingDues: 'বকেয়া',
  addContact: 'পরিচিতি যোগ করুন',
  
  // General
  edit: 'সম্পাদনা',
  delete: 'মুছে ফেলুন',
  save: 'সংরক্ষণ',
  cancel: 'বাতিল',
  language: 'ভাষা',
  english: 'ইংরেজি',
  bengali: 'বাংলা',
};

export type Translations = {
  en: typeof en;
  bn: typeof bn;
};

export const translations: Translations = {
  en,
  bn,
};
