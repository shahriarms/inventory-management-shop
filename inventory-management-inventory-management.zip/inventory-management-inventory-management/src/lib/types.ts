

export type Buyer = {
  id: number;
  name: string;
  phone: string | null;
  address: string | null;
  due: number;
};

export type Vendor = {
  id: number;
  name: string;
  phone: string | null;
};

export type Product = {
  id: number;
  name: string;
  sku: string;
  quantity: number;
  price: number;
};

export type Invoice = {
    id: number;
    buyer: string;
    date: string;
    total: number;
    due: number;
}

export type LineItem = {
  id: number;
  productName: string;
  productId: number | null;
  quantity: number;
  rate: number;
  discount: number;
};
