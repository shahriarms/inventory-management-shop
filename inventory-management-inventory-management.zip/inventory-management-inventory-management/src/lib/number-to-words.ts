// A simple number to Bengali words converter
// This is a basic implementation and can be expanded.

const units = ["", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়"];
const teens = ["দশ", "এগারো", "বারো", "তেরো", "চোদ্দো", "পনেরো", "ষোল", "সতেরো", "আঠারো", "উনিশ"];
const tens = ["", "", "বিশ", "ত্রিশ", "চল্লিশ", "পঞ্চাশ", "ষাট", "সত্তর", "আশি", "নব্বই"];

const convertLessThanOneThousand = (num: number): string => {
    let result = "";

    if (num >= 100) {
        result += units[Math.floor(num / 100)] + " শত ";
        num %= 100;
    }

    if (num >= 10 && num <= 19) {
        result += teens[num - 10] + " ";
    } else {
        if (num >= 20) {
            result += tens[Math.floor(num / 10)] + " ";
            num %= 10;
        }
        if (num > 0) {
            result += units[num] + " ";
        }
    }
    return result;
};


export const toWords = (num: number): string => {
    if (num === 0) {
        return "শূন্য";
    }

    let words = "";

    if (num >= 10000000) {
        words += convertLessThanOneThousand(Math.floor(num / 10000000)) + " কোটি ";
        num %= 10000000;
    }

    if (num >= 100000) {
        words += convertLessThanOneThousand(Math.floor(num / 100000)) + " লক্ষ ";
        num %= 100000;
    }

    if (num >= 1000) {
        words += convertLessThanOneThousand(Math.floor(num / 1000)) + " হাজার ";
        num %= 1000;
    }

    if (num > 0) {
        words += convertLessThanOneThousand(num);
    }

    return words.trim();
};
