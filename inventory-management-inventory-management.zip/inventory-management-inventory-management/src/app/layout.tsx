
import type { Metadata } from 'next';
import './globals.css';
import { LanguageProvider } from '@/contexts/language-context';
import { Toaster } from "@/components/ui/toaster"
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/app-layout/theme-provider';
import { AppProvider } from '@/components/app-layout/app-provider';
import { PrintProvider } from '@/contexts/print-context';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'Smart Inventory POS',
  description: 'A smart inventory and point-of-sale system by Firebase Studio',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={inter.variable}>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#F7F8FA" />
      </head>
      <body>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <LanguageProvider>
            <PrintProvider>
              <AppProvider>{children}</AppProvider>
              <Toaster />
            </PrintProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
