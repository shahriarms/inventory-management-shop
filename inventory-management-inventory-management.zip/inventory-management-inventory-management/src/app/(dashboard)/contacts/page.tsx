
import { getBuyers, getVendors } from "@/data/db";
import { ContactsClientPage } from "@/components/pages/contacts/contacts-client-page";

// This is now a Server Component
export default async function ContactsPage() {
  // Fetch data directly from the database on the server
  const initialBuyers = await getBuyers();
  const initialVendors = await getVendors();

  return (
    <ContactsClientPage 
      initialBuyers={initialBuyers} 
      initialVendors={initialVendors} 
    />
  );
}
