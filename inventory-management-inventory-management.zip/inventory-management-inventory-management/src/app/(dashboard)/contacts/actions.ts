
"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { addBuyer, updateBuyer, deleteBuyer, addVendor, updateVendor, deleteVendor } from "@/data/db";

const contactSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  phone: z.string().optional(),
  address: z.string().optional(),
});

type ContactType = 'buyers' | 'vendors';

export async function saveContactAction(formData: z.infer<typeof contactSchema>, type: ContactType) {
    const validatedFields = contactSchema.safeParse(formData);

    if (!validatedFields.success) {
        return {
            success: false,
            message: "Validation failed. Please check your inputs.",
        };
    }
    
    const { id, name, phone, address } = validatedFields.data;
    const phoneValue = phone || null;
    const addressValue = address || null;

    try {
        if (type === 'buyers') {
            if (id) {
                await updateBuyer(id, name, phoneValue, addressValue);
            } else {
                await addBuyer(name, phoneValue, addressValue);
            }
        } else { // type === 'vendors'
            if (id) {
                await updateVendor(id, name, phoneValue);
            } else {
                await addVendor(name, phoneValue);
            }
        }
        revalidatePath("/contacts");
        return {
            success: true,
            message: `Contact successfully ${id ? 'updated' : 'added'}.`,
        };
    } catch (error) {
        console.error(error);
        return {
            success: false,
            message: `Failed to ${id ? 'update' : 'add'} contact.`,
        };
    }
}

export async function deleteContactAction(id: number, type: ContactType) {
    try {
        if (type === 'buyers') {
            await deleteBuyer(id);
        } else {
            await deleteVendor(id);
        }
        revalidatePath("/contacts");
        return {
            success: true,
            message: "Contact successfully deleted.",
        };
    } catch (error) {
        console.error(error);
        return {
            success: false,
            message: "Failed to delete contact.",
        };
    }
}
