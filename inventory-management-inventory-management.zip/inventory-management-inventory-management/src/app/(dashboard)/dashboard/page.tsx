
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SalesChart } from "@/components/pages/dashboard/sales-chart"
import { StatsCards } from "@/components/pages/dashboard/stats-cards"
import { salesData, salesChartData } from "@/data/mock-data"
import { useLanguage } from "@/contexts/language-context";

export default function DashboardPage() {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Good day, Mahmud! 👋</h1>
        <p className="text-muted-foreground">Here's what's happening with your store today.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle>{t.salesOverview}</CardTitle>
              <CardDescription>A summary of your sales for the last 7 days.</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SalesChart salesChartData={salesChartData} />
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-1 flex flex-col gap-6">
           <StatsCards salesData={salesData} />
        </div>
      </div>
    </div>
  )
}
