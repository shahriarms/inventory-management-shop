
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { products as initialProducts } from "@/data/mock-data";
import { FileDown, FileUp, PlusCircle, Search, Edit, Trash2 } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";

export default function InventoryPage() {
  const { t } = useLanguage();
  const products = initialProducts;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <CardTitle>{t.inventory}</CardTitle>
            <div className="flex w-full md:w-auto items-center gap-2">
                <div className="relative w-full md:w-64">
                    <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground" />
                    <Input type="search" placeholder={t.searchProducts} className="pl-10" />
                </div>
                <Button variant="outline" size="icon"><FileUp className="h-4 w-4" /> <span className="sr-only">{t.import}</span></Button>
                <Button variant="outline" size="icon"><FileDown className="h-4 w-4" /> <span className="sr-only">{t.export}</span></Button>
                <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />{t.addProduct}
                </Button>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40%]">{t.productName}</TableHead>
              <TableHead>{t.sku}</TableHead>
              <TableHead className="text-right">{t.quantity}</TableHead>
              <TableHead className="text-right">{t.price}</TableHead>
              <TableHead className="text-center">{t.actions}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product) => (
              <TableRow key={product.id}>
                <TableCell className="font-medium">{product.name}</TableCell>
                <TableCell>{product.sku}</TableCell>
                <TableCell className="text-right">{product.quantity}</TableCell>
                <TableCell className="text-right">{formatCurrency(product.price)}</TableCell>
                <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-2">
                        <Button variant="outline" size="icon"><Edit className="h-4 w-4" /></Button>
                        <Button variant="destructive" size="icon"><Trash2 className="h-4 w-4" /></Button>
                    </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
