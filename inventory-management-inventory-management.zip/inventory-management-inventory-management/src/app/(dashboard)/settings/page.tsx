
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { usePrint, type PrintFormat } from "@/contexts/print-context";
import { useLanguage } from "@/contexts/language-context";

export default function SettingsPage() {
    const { printFormat, setPrintFormat } = usePrint();
    const { t } = useLanguage();

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">{t.settings}</h1>
                <p className="text-muted-foreground">Manage your application settings.</p>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle>Printing</CardTitle>
                    <CardDescription>Choose the default print format for your invoices.</CardDescription>
                </CardHeader>
                <CardContent>
                    <RadioGroup
                        value={printFormat}
                        onValueChange={(value: PrintFormat) => setPrintFormat(value)}
                        className="space-y-2"
                    >
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="a4" id="a4" />
                            <Label htmlFor="a4">A4 / Full Page</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="receipt" id="receipt" />
                            <Label htmlFor="receipt">Thermal Receipt (80mm)</Label>
                        </div>
                    </RadioGroup>
                </CardContent>
            </Card>
        </div>
    );
}
