
"use client"

import { useState, useEffect, useTransition, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useLanguage } from "@/contexts/language-context";
import { products as mockProducts, buyers as mockBuyers } from "@/data/mock-data";
import { PlusCircle, Trash2, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { Separator } from "@/components/ui/separator";
import { Combobox } from "@/components/ui/combobox";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import type { Buyer, Product, LineItem } from "@/lib/types";
import { toWords } from "@/lib/number-to-words";
import { usePrint } from "@/contexts/print-context";
import { cn } from "@/lib/utils";


let nextItemId = 1;

export default function NewInvoicePage() {
  const router = useRouter();
  const { t } = useLanguage();
  const { toast } = useToast();
  const { printFormat, setPrintFormat } = usePrint();

  const [lineItems, setLineItems] = useState<LineItem[]>([]);
  const [paidAmount, setPaidAmount] = useState<number | ''>('');
  
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [buyers, setBuyers] = useState<Buyer[]>(mockBuyers.sort((a, b) => a.name.localeCompare(b.name)));
  
  const [selectedBuyer, setSelectedBuyer] = useState<Buyer | null>(null);
  const [currentAddress, setCurrentAddress] = useState('');
  const [currentPhone, setCurrentPhone] = useState('');
  const [invoiceDate, setInvoiceDate] = useState<Date | null>(null);
  const [invoiceNumber, setInvoiceNumber] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isFormPending, startFormTransition] = useTransition();

  const printRef = useRef(null);
  const [amountInWords, setAmountInWords] = useState(t.amountInWordsPlaceholder);
  
  // State to track if paidAmount has been manually changed by the user.
  const [paidAmountTouched, setPaidAmountTouched] = useState(false);

  const subtotal = lineItems.reduce((acc, item) => {
    return acc + (item.quantity * item.rate);
  }, 0);

  const finalPaidAmount = Number(paidAmount) || 0;
  // This is the core logic change.
  const due = paidAmountTouched ? subtotal - finalPaidAmount : 0;

  useEffect(() => {
    // Generate invoice number and date on the client side to avoid hydration errors
    setInvoiceNumber(String(Math.floor(Math.random() * 10000) + 1000));
    setInvoiceDate(new Date());
  }, []);

  useEffect(() => {
    if (subtotal > 0) {
      const words = toWords(subtotal);
      const formattedWords = words.charAt(0).toUpperCase() + words.slice(1) + " টাকা মাত্র";
      setAmountInWords(formattedWords);
    } else {
      setAmountInWords(t.amountInWordsPlaceholder);
    }
  }, [subtotal, t.amountInWordsPlaceholder]);


  const handleAddItem = () => {
    setLineItems([...lineItems, { id: nextItemId++, productId: null, productName: "", quantity: 1, rate: 0, discount: 0 }]);
  };

  const handleRemoveItem = (id: number) => {
    setLineItems(lineItems.filter(item => item.id !== id));
  };

  const handleItemChange = (id: number, field: keyof LineItem, value: any) => {
    setLineItems(prevItems => {
        const items = [...prevItems];
        const itemIndex = items.findIndex(item => item.id === id);
        if (itemIndex === -1) return items;

        const currentItem = { ...items[itemIndex] };

        if (field === 'productId') {
            const product = products.find(p => p.id === Number(value));
            if (product) {
                currentItem.rate = product.price;
                currentItem.productName = product.name;
                currentItem.productId = product.id;
            }
        } else {
            (currentItem[field] as any) = value;
        }

        items[itemIndex] = currentItem;
        return items;
    });
  };
  
  const handleBuyerChange = (buyerId: string) => {
    const buyer = buyers.find(b => b.id === Number(buyerId)) || null;
    setSelectedBuyer(buyer);
    setCurrentAddress(buyer?.address || '');
    setCurrentPhone(buyer?.phone || '');
  };

  const handleAddBuyer = (newBuyerName: string) => {
    startFormTransition(() => {
        const newBuyer: Buyer = {
            id: Date.now(),
            name: newBuyerName,
            address: '',
            phone: '',
            due: 0
        };
        const sortedBuyers = [...buyers, newBuyer].sort((a,b) => a.name.localeCompare(b.name));
        setBuyers(sortedBuyers);
        setSelectedBuyer(newBuyer);
        setCurrentAddress(newBuyer.address || '');
        setCurrentPhone(newBuyer.phone || '');
        toast({
            title: "Buyer added",
            description: `${newBuyer.name} has been successfully added.`,
        });
    });
  };

    const handlePrint = (): Promise<boolean> => {
        return new Promise((resolve) => {
            const printContent = printRef.current;
            if (!printContent) {
                toast({ title: "Error", description: "Print content not found.", variant: "destructive" });
                return resolve(false);
            }

            const printHtml = (printContent as any).innerHTML;
            const styles = Array.from(document.styleSheets)
                .map(styleSheet => {
                    try {
                        return Array.from(styleSheet.cssRules).map(rule => rule.cssText).join('');
                    } catch (e) {
                        console.warn("Could not read stylesheet rules", e);
                        return '';
                    }
                }).join('\n');
            
            const printStyles = `
                @media print {
                    @page {
                        size: ${printFormat === 'a4' ? 'A4' : '80mm auto'};
                        margin: ${printFormat === 'a4' ? '1cm' : '0'};
                    }
                    html, body {
                        height: auto !important;
                        min-height: 0 !important;
                        overflow: visible !important;
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                }
            `;
            
            const iframe = document.createElement('iframe');
            iframe.style.position = 'fixed';
            iframe.style.width = '0';
            iframe.style.height = '0';
            iframe.style.border = 'none';
            document.body.appendChild(iframe);

            const doc = iframe.contentWindow?.document;
            if (!doc) {
                document.body.removeChild(iframe);
                toast({ title: "Error", description: "Could not create print document.", variant: "destructive" });
                return resolve(false);
            }

            doc.open();
            doc.write(`<html><head><style>${styles}${printStyles}</style></head><body>${printHtml}</body></html>`);
            doc.close();

            let printed = false;
            const printAndResolve = () => {
                try {
                    printed = doc.execCommand('print', false, undefined);
                } catch (e) {
                    iframe.contentWindow?.print();
                }

                if (!printed) {
                     iframe.contentWindow?.print();
                }
            };
            
            const handleFocus = () => {
                if (!printed) {
                    // If focus returns immediately and we haven't printed, it's likely a cancel.
                    window.removeEventListener('focus', handleFocus);
                    document.body.removeChild(iframe);
                    resolve(false);
                }
            };

            window.addEventListener('focus', handleFocus);
            
            iframe.onload = () => {
                printAndResolve();
                // If the print dialog is confirmed, focus won't return immediately.
                // We'll assume success after a short delay.
                setTimeout(() => {
                    window.removeEventListener('focus', handleFocus);
                    if(!iframe.parentNode) return; // already removed
                    document.body.removeChild(iframe);
                    resolve(true);
                }, 500);
            };
        });
    };

    const handleSaveInvoice = async () => {
        if (!selectedBuyer) {
            toast({ title: "Error", description: "Please select a buyer.", variant: "destructive"});
            return;
        }
        if (lineItems.length === 0 || lineItems.every(item => !item.productId)) {
            toast({ title: "Error", description: "Please add at least one item to the invoice.", variant: "destructive"});
            return;
        }
        if (lineItems.some(item => !item.productId)) {
            toast({ title: "Error", description: "Please select a product for all line items.", variant: "destructive"});
            return;
        }
        
        setIsSaving(true);
        
        const printConfirmed = await handlePrint();

        if (printConfirmed) {
            // Simulate saving AFTER printing was confirmed
            setTimeout(() => {
                toast({
                    title: "Invoice Saved",
                    description: "The invoice has been successfully saved.",
                });
                setIsSaving(false);
                // Optional: Reset form or navigate away
                // router.push('/invoices');
            }, 500);
        } else {
            // Print was canceled, so we don't save
            setIsSaving(false);
            toast({
                title: "Canceled",
                description: "Invoice was not saved because printing was canceled.",
                variant: "destructive"
            });
        }
    }


  const formatCurrencyBare = (amount: number | '') => {
    const num = Number(amount);
    if (isNaN(num)) return '0.00';
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  };

  const buyerOptions = buyers.map(buyer => ({
    value: buyer.id.toString(),
    label: buyer.name,
    address: buyer.address || ''
  }));

  const productOptions = products.map(p => ({ 
    value: p.id.toString(), 
    label: p.name 
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Left Side: Form */}
        <div className="space-y-6">
             <Card>
                <CardHeader>
                    <CardTitle>{t.invoiceInfo}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="font-medium">
                            {t.invoiceNo}: <span className="text-foreground">{invoiceNumber || '...'}</span>
                        </div>
                        <div className="font-medium text-right">
                            {t.date}: <span className="text-foreground">{invoiceDate ? format(invoiceDate, 'dd/MM/yyyy') : '...'}</span>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="buyer">{t.name}</Label>
                        <Combobox
                            options={buyerOptions}
                            onSelect={handleBuyerChange}
                            onAdd={handleAddBuyer}
                            placeholder={t.selectBuyer}
                            searchPlaceholder="Search or add buyer..."
                            selectedValue={selectedBuyer?.id.toString()}
                            isAdding={isFormPending}
                        />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="address">{t.address}</Label>
                        <Input id="address" placeholder={t.enterBuyerAddress} value={currentAddress} onChange={(e) => setCurrentAddress(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="phone">{t.phone}</Label>
                        <Input id="phone" placeholder="Enter phone number" value={currentPhone} onChange={(e) => setCurrentPhone(e.target.value)} />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>{t.addProducts}</CardTitle>
                </CardHeader>
                <CardContent>
                     <div className="space-y-4">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                <TableHead className="w-[45%]">{t.item}</TableHead>
                                <TableHead>{t.quantity}</TableHead>
                                <TableHead>{t.rate}</TableHead>
                                <TableHead className="text-right">{t.total}</TableHead>
                                <TableHead></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {lineItems.map((item) => (
                                <TableRow key={item.id}>
                                    <TableCell>
                                        <Combobox
                                            options={productOptions}
                                            onSelect={(v) => handleItemChange(item.id, 'productId', v)}
                                            placeholder={t.selectItem}
                                            searchPlaceholder="Search item..."
                                            selectedValue={item.productId?.toString()}
                                        />
                                    </TableCell>
                                    <TableCell>
                                    <Input type="number" value={item.quantity} onChange={(e) => handleItemChange(item.id, 'quantity', Number(e.target.value))} className="w-20" />
                                    </TableCell>
                                    <TableCell>
                                    <Input type="number" value={item.rate} onChange={(e) => handleItemChange(item.id, 'rate', Number(e.target.value))} className="w-24"/>
                                    </TableCell>
                                    <TableCell className="text-right font-medium">{formatCurrencyBare((item.quantity * item.rate))}</TableCell>
                                    <TableCell>
                                    <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(item.id)}>
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                    </TableCell>
                                </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        <Button variant="outline" onClick={handleAddItem} className="w-full">
                            <PlusCircle className="mr-2 h-4 w-4"/> {t.addLineItem}
                        </Button>
                    </div>
                </CardContent>
            </Card>
            
            <Card>
                <CardContent className="pt-6">
                    <div className="grid grid-cols-1 gap-4">
                        <div>
                            <Label htmlFor="paidAmount">{t.paidAmount}</Label>
                            <Input id="paidAmount" type="number" value={paidAmount} onChange={(e) => {
                                setPaidAmount(e.target.value === '' ? '' : Number(e.target.value));
                                setPaidAmountTouched(true);
                            }} placeholder="0.00"/>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardContent className="space-y-3 pt-6 text-lg">
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">{t.subtotal}</span>
                        <span className="font-semibold">{formatCurrencyBare(subtotal)}</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">{t.paidAmount}</span>
                        <span className="font-semibold">{formatCurrencyBare(finalPaidAmount)}</span>
                    </div>
                     <div className="flex justify-between items-center font-bold text-xl">
                        <span className="text-primary">{t.due}</span>
                        <span className="text-primary">{formatCurrencyBare(due)}</span>
                    </div>
                </CardContent>
            </Card>


             <Button size="lg" className="w-full" onClick={handleSaveInvoice} disabled={isSaving}>
                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {t.saveAndPrintInvoice}
            </Button>
        </div>

        {/* Right Side: Preview */}
        <div className="sticky top-4 space-y-4">
             <h3 className="text-lg font-semibold text-center">Print Preview</h3>
             <div className="flex justify-center gap-2">
                <Button size="sm" variant={printFormat === 'a4' ? 'default' : 'outline'} onClick={() => setPrintFormat('a4')}>A4</Button>
                <Button size="sm" variant={printFormat === 'receipt' ? 'default' : 'outline'} onClick={() => setPrintFormat('receipt')}>POS Receipt</Button>
            </div>
            <div ref={printRef} className={cn(
                "border rounded-lg shadow-sm overflow-hidden",
                printFormat === 'receipt' && "max-w-[302px] mx-auto" // 80mm receipt width
            )}>
                <Card>
                    <CardHeader className="items-center text-center">
                        <div className={cn(
                            "border-2 border-primary text-primary font-bold px-4 py-1 text-lg rounded-md",
                            printFormat === 'receipt' && "text-base px-2 py-0.5"
                        )} style={{width: 'fit-content'}}>
                            {t.cashMemo}
                        </div>
                        <div className="pt-4">
                            <h2 className={cn(
                                "text-2xl font-bold text-primary",
                                printFormat === 'receipt' && "text-xl"
                            )}>মাহমুদ ইঞ্জিনিয়ারিং শপ</h2>
                            <p className={cn(
                                "text-sm text-muted-foreground max-w-md mx-auto",
                                printFormat === 'receipt' && "text-xs"
                            )}>{t.shopAddress}</p>
                            <p className={cn(
                                "text-sm text-muted-foreground",
                                printFormat === 'receipt' && "text-xs"
                            )}>{t.shopContact}</p>
                        </div>
                    </CardHeader>
                    <CardContent className={cn("space-y-4", printFormat === 'receipt' && "text-sm p-2")}>
                        <Separator />
                        <div className={cn("grid grid-cols-2 gap-4", printFormat === 'receipt' && "grid-cols-1 text-center")}>
                            <div>{t.invoiceNo}: {invoiceNumber || '...'}</div>
                            <div className={cn("text-right", printFormat === 'receipt' && "text-center")}>{t.date}: {invoiceDate ? format(invoiceDate, 'dd/MM/yyyy') : '...'}</div>
                            <div className="col-span-2">
                                <p>{t.name}: {selectedBuyer?.name || '...........................................................'}</p>
                                <p>{t.phone}: {currentPhone || '......................................................'}</p>
                                <p>{t.address}: {currentAddress || '......................................................'}</p>
                            </div>
                        </div>
                        
                        <h3 className="font-bold text-center">{t.invoiceItems}</h3>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                <TableHead>{t.serialNo}</TableHead>
                                <TableHead>{t.itemDescription}</TableHead>
                                <TableHead className="text-right">{t.quantity}</TableHead>
                                <TableHead className="text-right">{t.rate}</TableHead>
                                <TableHead className="text-right">{t.amount}</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {lineItems.map((item, index) => ( item.productId &&
                                <TableRow key={item.id}>
                                    <TableCell>{index + 1}</TableCell>
                                    <TableCell>{item.productName}</TableCell>
                                    <TableCell className="text-right">{item.quantity}</TableCell>
                                    <TableCell className="text-right">{formatCurrencyBare(item.rate)}</TableCell>
                                    <TableCell className="text-right">{formatCurrencyBare(item.quantity * item.rate)}</TableCell>
                                </TableRow>
                                ))}
                                {lineItems.filter(i => i.productId).length === 0 && (
                                    <TableRow>
                                        <TableCell colSpan={5} className="text-center text-muted-foreground">{t.noItemsAdded}</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>

                        <div className="flex justify-end pt-4">
                            <div className="w-full md:w-1/2 space-y-1 text-right">
                                <div className="flex justify-between">
                                    <span>{t.subtotal} =</span>
                                    <span className="font-medium">{formatCurrencyBare(subtotal)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>{t.paidAmount} =</span>
                                    <span className="font-medium">{formatCurrencyBare(finalPaidAmount)}</span>
                                </div>
                                <div className="flex justify-between font-bold">
                                    <span>{t.due} =</span>
                                    <span className="font-medium">{formatCurrencyBare(due)}</span>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-1 pt-4">
                            <p className="font-medium">{t.amountInWords}:</p>
                            <div className="border rounded-md p-2 text-center bg-muted/50">
                                <p>{amountInWords}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    </div>
  );
}
