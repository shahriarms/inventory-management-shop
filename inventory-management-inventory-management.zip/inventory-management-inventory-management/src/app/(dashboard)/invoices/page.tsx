
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useLanguage } from "@/contexts/language-context";
import { invoices as initialInvoices } from "@/data/mock-data";
import { PlusCircle } from "lucide-react";
import Link from "next/link";


export default function InvoicesPage() {
  const { t } = useLanguage();
  const invoices = initialInvoices;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{t.invoices}</CardTitle>
          <Button asChild>
            <Link href="/invoices/new">
              <PlusCircle className="h-4 w-4 mr-2" />
              {t.createInvoice}
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t.invoice} #</TableHead>
              <TableHead>{t.buyerInfo}</TableHead>
              <TableHead>{t.invoiceDate}</TableHead>
              <TableHead className="text-right">{t.total}</TableHead>
              <TableHead className="text-right">{t.due}</TableHead>
              <TableHead className="text-center">{t.actions}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.map((invoice: any) => (
              <TableRow key={invoice.id}>
                <TableCell className="font-medium">{invoice.id}</TableCell>
                <TableCell>{invoice.buyer}</TableCell>
                <TableCell>{new Date(invoice.date).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">{formatCurrency(invoice.total)}</TableCell>
                <TableCell className="text-right text-red-600">{formatCurrency(invoice.due)}</TableCell>
                <TableCell className="text-center">
                  <Button variant="outline" size="sm">{t.edit}</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
