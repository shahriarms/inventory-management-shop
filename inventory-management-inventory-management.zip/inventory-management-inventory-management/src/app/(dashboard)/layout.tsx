
"use client"

import { usePathname } from "next/navigation"
import { getNavItems } from "@/components/app-layout/nav"
import { useLanguage } from "@/contexts/language-context"
import { Sidebar, SidebarProvider, SidebarTrigger, SidebarContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset, useSidebar } from "@/components/ui/sidebar"
import Link from "next/link"
import { LanguageToggle } from "@/components/app-layout/language-toggle"
import { ThemeToggle } from "@/components/app-layout/theme-toggle"
import { Boxes } from "lucide-react"
import { cn } from "@/lib/utils"

function Logo() {
    const { open, isMobile } = useSidebar();
    if (isMobile) return null;
    return (
        <div className={cn(
            "flex items-center gap-2 transition-opacity duration-300",
            open ? "opacity-0" : "opacity-100"
        )}>
            <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
                <Boxes className="h-5 w-5" />
            </div>
            <span className="font-bold text-lg">SmartPOS</span>
        </div>
    )
}


export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { t } = useLanguage()
  const pathname = usePathname()
  const navItems = getNavItems(t)
  
  return (
    <SidebarProvider>
      <Sidebar side="left" collapsible="icon" className="bg-sidebar" variant="inset">
        <SidebarContent>
          <SidebarMenu>
            {navItems.map(item => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href}
                  tooltip={{
                    children: item.label,
                    side: "right",
                    align: "center",
                  }}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
      </Sidebar>
      <SidebarInset className="main-content m-2 rounded-xl shadow bg-card">
        <header className="flex h-16 items-center justify-between px-6 border-b">
          <div className="flex items-center gap-4">
            <SidebarTrigger />
            <Logo />
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <LanguageToggle />
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
