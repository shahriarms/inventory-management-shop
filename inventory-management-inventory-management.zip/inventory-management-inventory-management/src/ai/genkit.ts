/**
 * @fileoverview This file initializes the Genkit AI instance with necessary plugins.
 * It serves as the central point for configuring Genkit's behavior, including the AI model provider.
 */
import { genkit } from '@genkit-ai/ai';
import { googleAI } from '@genkit-ai/googleai';

// Initialize the Genkit AI instance with the Google AI plugin.
// This allows the application to use Google's AI models (e.g., Gemini) for generative tasks.
// The `ai` object is exported so it can be used to define flows, prompts, and tools throughout the application.
export const ai = genkit({
  plugins: [
    googleAI(),
  ],
});
