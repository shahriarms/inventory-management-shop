
"use client"

import React, { createContext, useState, useContext, useEffect } from 'react';
import type { ReactNode } from 'react';
import { translations, type Language, type Translations } from '@/lib/i18n';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: Translations[Language];
  isMounted: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Fallback for server-side rendering or when context is not available
const defaultContextValue: LanguageContextType = {
    language: 'bn', // Default to Bengali
    setLanguage: () => {}, // No-op function
    t: translations.bn,
    isMounted: false,
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState<Language>('bn');
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    // This effect runs only on the client side after the component has mounted.
    const getInitialLanguage = (): Language => {
        const savedLang = localStorage.getItem('app-language');
        if (savedLang === 'en' || savedLang === 'bn') {
          return savedLang;
        }
      return 'bn';
    };
    
    setLanguageState(getInitialLanguage());
    setIsMounted(true);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('app-language', lang);
    }
  };

  const t = translations[language];

  const value = { language, setLanguage, t, isMounted };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  // If the context is not available (e.g., during server render), return the default value.
  return context === undefined ? defaultContextValue : context;
};
