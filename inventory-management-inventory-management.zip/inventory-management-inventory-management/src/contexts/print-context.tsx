
"use client"

import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

export type PrintFormat = 'a4' | 'receipt';

interface PrintContextType {
  printFormat: PrintFormat;
  setPrintFormat: (format: PrintFormat) => void;
  isMounted: boolean;
}

const PrintContext = createContext<PrintContextType | undefined>(undefined);

const defaultContextValue: PrintContextType = {
    printFormat: 'receipt', // Default to POS receipt
    setPrintFormat: () => {},
    isMounted: false,
};

export const PrintProvider = ({ children }: { children: ReactNode }) => {
  const [printFormat, setPrintFormatState] = useState<PrintFormat>('receipt');
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const getInitialFormat = (): PrintFormat => {
      const savedFormat = localStorage.getItem('app-print-format');
      if (savedFormat === 'a4' || savedFormat === 'receipt') {
        return savedFormat;
      }
      return 'receipt'; // Default to POS Receipt
    };
    
    setPrintFormatState(getInitialFormat());
    setIsMounted(true);
  }, []);

  const setPrintFormat = (format: PrintFormat) => {
    setPrintFormatState(format);
    if (typeof window !== 'undefined') {
      localStorage.setItem('app-print-format', format);
    }
  };

  const value = { printFormat, setPrintFormat, isMounted };

  return (
    <PrintContext.Provider value={value}>
      {children}
    </PrintContext.Provider>
  );
};

export const usePrint = (): PrintContextType => {
  const context = useContext(PrintContext);
  return context === undefined ? defaultContextValue : context;
};

    