
import { sql } from "@vercel/postgres";
import { config } from "dotenv";

// Load environment variables from .env.local file
config({ path: ".env.local" });

async function setupDatabase() {
  console.log("Starting database setup...");

  try {
    // Create buyers table
    await sql`
      CREATE TABLE IF NOT EXISTS buyers (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50),
        address TEXT,
        due NUMERIC(10, 2) DEFAULT 0
      );
    `;
    console.log('Table "buyers" created or already exists.');

    // Create vendors table
    await sql`
      CREATE TABLE IF NOT EXISTS vendors (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50)
      );
    `;
    console.log('Table "vendors" created or already exists.');

    // Create products table
    await sql`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        sku VARCHAR(100) UNIQUE,
        quantity INTEGER NOT NULL,
        price NUMERIC(10, 2) NOT NULL
      );
    `;
    console.log('Table "products" created or already exists.');

    // Create invoices table
    await sql`
      CREATE TABLE IF NOT EXISTS invoices (
        id SERIAL PRIMARY KEY,
        buyer_id INTEGER REFERENCES buyers(id),
        invoice_date DATE NOT NULL,
        total_amount NUMERIC(10, 2) NOT NULL,
        paid_amount NUMERIC(10, 2) NOT NULL,
        due_amount NUMERIC(10, 2) NOT NULL
      );
    `;
    console.log('Table "invoices" created or already exists.');

    // Create invoice_items table
    await sql`
      CREATE TABLE IF NOT EXISTS invoice_items (
        id SERIAL PRIMARY KEY,
        invoice_id INTEGER REFERENCES invoices(id) ON DELETE CASCADE,
        product_id INTEGER REFERENCES products(id),
        quantity INTEGER NOT NULL,
        rate NUMERIC(10, 2) NOT NULL,
        discount NUMERIC(10, 2) DEFAULT 0
      );
    `;
    console.log('Table "invoice_items" created or already exists.');

    console.log("Database setup completed successfully!");
  } catch (error) {
    console.error("Error setting up the database:", error);
    // Exit with an error code to indicate failure
    process.exit(1);
  }
}

setupDatabase();
