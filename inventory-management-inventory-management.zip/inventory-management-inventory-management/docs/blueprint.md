# **App Name**: Smart Inventory POS

## Core Features:

- Invoice Management: Invoice creation with buyer info, item details, quantity, rate, discounts, dues, and timestamp. Auto-inserts transactions into the local PostgreSQL database.
- Stock/Inventory Management: Manual product/stock updates, batch updates, and real-time updates with offline-first design. Add/edit/delete product info with SKU/barcode support.
- Dashboard + Analytics: Dashboard with daily, weekly, monthly sales stats, visual charts, expenses summary, and real-time overview of profit, loss, and total items sold.
- Excel Export/Import: Export any table (sales, inventory, buyer list) to Excel format. Export daily reports or full data. Re-import updated data to sync into PostgreSQL.
- Sales Deletion Restriction: Selling data can be deleted only directly from PostgreSQL for security and audit log. No delete access via the web interface.
- Vendor & Buyer Management: Manage vendor contact list with supply records and buyers with outstanding dues (Baki) and contact details. Auto-manage dues via invoice selection.
- Language Toggle Support: Support for Bengali and English interface elements. Language toggle button in the header or sidebar. Modular JSON language files for i18n. Dynamic switching for all form labels, button texts, menus, messages, and dashboard metrics.
- Bonus Features: QR/barcode scan for fast product search.  Make the app fully installable via Chrome/Edge as PWA. Support modular extensions later (e.g., accounting, user roles).

## Style Guidelines:

- Primary color: Blue (#4285F4) for a professional look.
- Background color: Light gray (#F5F5F5) for a clean and modern backdrop.
- Accent color: Green (#34A853) to highlight important actions.
- Body and headline font: 'Inter' (sans-serif) for clear readability.
- Use clean, professional icons from a standard library like Material Icons.
- Maintain a responsive layout to ensure usability on various devices.
- Incorporate subtle transitions and feedback animations to improve user experience.